export class Employee{
    accNo:number;
    pwd:string;
    name:string;
    mobNo:number;
   
    address:string;
    bal:number;
    constructor(accNo:number,
        pwd:string,
        name:string,
        mobNo:number,
       
        address:string,
        bal:number){
            this.accNo=accNo;
            this.pwd=pwd;
            this.name=name;
            this.mobNo=mobNo;
            this.address=address;
            this.bal=bal;
        }
}