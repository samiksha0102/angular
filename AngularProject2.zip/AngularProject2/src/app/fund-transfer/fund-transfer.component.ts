import { Component, OnInit } from '@angular/core';
import { Transaction } from 'src/Transaction';
import { MyServiceService } from '../my-service.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  isLogin:boolean=true;
  createdTransaction:Transaction;
  
 
  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;}
  ngOnInit() {
  }
  fundTransfer(data:any){
    let caccount_first=data.caccount;
    let caccount_second=data.caccount_second;
    let cbalance=data.cbalance;

    this.service.depositBalance(caccount_first,cbalance);
    this.service.withdrawBalance(caccount_second,cbalance)
    
    this.createdTransaction=new Transaction(data.transNo,data.accno,data.transType,data.previousBal,data.currentBal);
    this.service.addTransaction(this.createdTransaction)
  }

}
