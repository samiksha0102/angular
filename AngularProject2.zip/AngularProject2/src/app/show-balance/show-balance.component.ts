import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/Employee';
import { MyServiceService } from '../my-service.service';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {

  isLogin:boolean=true;
  employees:Employee[]=[];
  cbalance:number;
  isShowBalance:boolean=true;

  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;}

  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }
  showBalance(data:any){
    this.cbalance=this.service.showBalance(data);
    this.isShowBalance=!this.isShowBalance;
    
  }
}
