import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Employee } from 'src/Employee';
import { Transaction } from 'src/Transaction';
@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http:HttpClient;
  isLogin:boolean=true;
  employees:Employee[]=[];
  transactions:Transaction[]=[];
  tempTransaction:Transaction[]=[];

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchEmployees();
    this.fetchTransactions();
  }

  fetched:boolean=false;
  fetchedT:boolean=false;


  fetchTransactions() {
    this.http.get('./assets/Employee.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }
  convert(data:any) {
    for(let o of data)
    {
      let e=new Employee(o.caccount,o.cname,o.cphone,o.cpassword,o.ccity,o.cbalance);
      this.employees.push(e);
    }
  }
  showBalance(data: Employee){
    let accNo = data.accNo; 
    for(let i=0;i<this.employees.length;i++)
      {
        if(accNo == this.employees[i].accNo)
        {
          //alert(this.employees[i].cbalance)
          let bal=this.employees[i].bal;
          return bal;
        }else{
          alert("Account No does not matched!")
        }
      }
  }
  withdrawBalance(accNo_first: number, bal:number){
    console.log(accNo_first,bal)

    for(let i=0;i<this.employees.length;i++)
    {
      if(accNo_first == this.employees[i].accNo)
      {
        let dpt:number=this.employees[i].bal;
        this.employees[i].bal=dpt- bal;
        alert(10 + 30)
        // alert(this.employees[i].cbalance);
        alert("Amount Withdrawn from "+accNo_first+" Updated Balance : "+this.employees[i].bal);
        break;
      }
    }
  }
  depositBalance(accNo_first: number, bal:number): any {
    console.log(accNo_first,bal)

    for(let i=0;i<this.employees.length;i++)
    {
      if(accNo_first == this.employees[i].accNo)
      {
        let dpt:number=this.employees[i].bal;
        this.employees[i].bal=dpt +bal;
        alert(10 + 30)
       
        alert("Amount Deposited from "+accNo_first+" Updated Balance : "+this.employees[i].bal);
        break;
      }
    }
  }
  getEmployees(): Employee[]{
    return this.employees;
  }
  fetchEmployees(): any {
    this.http.get('./assets/Transactions.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetchedT)
        {
          this.convertTransaction(data);
          this.fetchedT=true;
        }
      }
    );
  }
  convertTransaction(data: any) {
    for(let o of data)
    {
      let e=new Transaction(data.transNo,data.accno,data.transType,data.previousBal,data.currentBal);
      this.transactions.push(e);
      console.log(this.transactions)
    }
  }
  addTransaction(t:Transaction){
    this.transactions.push(t);
  }

  miniStatement(caccount:number):Transaction[]{
  this.tempTransaction=[];
  for(let i=0;i<this.transactions.length;i++)
  {
    let e=this.transactions[i];
    if(caccount==e.transNo)
    {
      this.tempTransaction.push(e);
    }
  }
  return this.tempTransaction;
}
delete(accNo:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.employees.length;i++)
    {
      let emp=this.employees[i];
      if(accNo==emp.accNo)
      {
        foundIndex=i;
        break;
      }
    }
    this.employees.splice(foundIndex,1);
  }

}
